# VectorLite — minimal MVP

Simple lightweight vector store MVP.

## Quickstart

Install requirement(s):
